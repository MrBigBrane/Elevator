#include <iostream>
#include <string>
#include "Elevator.h"
#include <cstdlib>

using namespace std;

int main() { 
  int floors = 10;
  
  Elevator elevator(floors);
  string dir;
  int desFloor;

  srand(10);

  cout << "Where would you like to go? (up/down or -1 to exit): ";
  cin >> dir;
  
  while(dir != "-1") {
    while(dir != "up" && dir != "down") {
      cout << "Invalid direction. Where would you like to go? (up/down): ";
      cin >> dir;
    }
  
    elevator.ExternalReq(dir);
  
    cout << "Which floor would you like to go to: ";
    cin >> desFloor;
    while(desFloor > floors || desFloor <= 0) {
      cout << "Invalid floor number pressed. Which floor would you like to go to: ";
      cin >> desFloor;
    }
  
    elevator.ButtonPress(desFloor, true);
    elevator.ButtonPress(rand() % 9 + 1, false);
    elevator.ButtonPress(rand() % 9 + 1, false);
    elevator.ButtonPress(rand() % 9 + 1, false);
    elevator.PrintElevatorStatus();
    elevator.Moving();

    cout << "Where would you like to go? (up/down or -1 to exit): ";
    cin >> dir;
  }

  return 0;
}