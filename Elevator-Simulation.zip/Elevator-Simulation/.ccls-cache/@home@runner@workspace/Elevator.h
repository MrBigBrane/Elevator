#ifndef ELEVATOR_H
#define ELEVATOR_H

#include <string>
#include <vector>
#include <utility>

using namespace std;

class Elevator {
public:
    Elevator(int floors);

    void ButtonPress(int desFloor, bool user); // Simulate someone pressing elevator button
    void ExternalReq(string dir);
    void Moving();
    void PrintElevatorStatus();

private:
    bool open;
    string direction;
    int numFloors;
    int currFloor;
    int userFloor;
    vector<pair<int, bool>> pressedFloors;
};

#endif 