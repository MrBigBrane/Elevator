#include <iostream>
#include <cctype>
#include <vector>
#include <string>
#include "Elevator.h"
#include <cstdlib>
#include <thread> 
#include <chrono> 
#include <cstdlib>
#include <algorithm>
#include <utility>


using namespace std;

void Open() {
   cout << "Doors opening..." << endl;
   this_thread::sleep_for(chrono::milliseconds(500));
   cout << "Doors opened!" << endl;
   this_thread::sleep_for(chrono::milliseconds(500));
}

void Close() {
   cout << "Doors closing..." << endl;
   this_thread::sleep_for(chrono::milliseconds(500));
   cout << "Doors closed!" << endl;
   this_thread::sleep_for(chrono::milliseconds(500));
}

// Sets elevator to default position/settings
Elevator::Elevator(int floors) {
   numFloors = floors;
   open = false;
   direction = "up";
   currFloor = 1;
   userFloor = 1;
}

void Elevator::ExternalReq(string dir) {
   cout << "User Floor: " << userFloor << endl;
   cout << "Curr Floor: " << currFloor << endl;
   if(currFloor - userFloor > 0) {
      direction = "down";
   }
   else {
      direction = "up";
   }
   int startFloor = currFloor;
   
   for (int i = 0; i < abs(startFloor - userFloor); ++i) {
      if(direction == "up") {
         ++currFloor;
         cout << "Current Floor: " << currFloor << "\t" << "Direction: Heading " << direction << endl;
         this_thread::sleep_for(chrono::milliseconds(500));
      }
      else if(direction == "down") {
         --currFloor;
         cout << "Current Floor: " << currFloor << "\t" << "Direction: Heading " << direction << endl;
         this_thread::sleep_for(chrono::milliseconds(500));
      }
   }
   
   cout << "*Ding* The elevator has arrived on floor " << currFloor << endl;
   Open();
   cout << "You have entered the elevator." << endl;
   Close();
   
   direction = dir;
} 

// Inserts floor number pressed in ascending order in vector containing all button presses
void Elevator::ButtonPress(int desFloor, bool user) {
   this_thread::sleep_for(chrono::milliseconds(500));
   cout << "Button Pressed: " << desFloor << endl;

   int newDesFloor;
   pair<int, bool> button(desFloor, user);
   
   auto alreadyPressed = find_if( pressedFloors.begin(), pressedFloors.end(),
    [desFloor] (pair<int, bool>& element) { return element.first == desFloor; } );

   if(desFloor == currFloor) {
      cout << "Passenger has requested to go to the floor they are currently on. Please try again." << endl;
      while(desFloor == currFloor) {
         newDesFloor = rand() % 9 + 1;
         cout << "Button Pressed: " << newDesFloor << endl;
      }
      button.first = newDesFloor;
      pressedFloors.push_back(button);
   }
   else if(alreadyPressed != pressedFloors.end()) {
      cout << "This button has already been pressed." << endl;
      return;
   }
   else {
      pressedFloors.push_back(button);
   }
   
   if(pressedFloors.size() > 0) {
      if(direction == "up") {
         sort(pressedFloors.begin(), pressedFloors.end(), [this](const pair<int, bool>& a, const pair<int, bool>& b) {
               return 1 / (a.first - currFloor) > 1 / (b.first - currFloor);
           });
      }
      else {
         sort(pressedFloors.begin(), pressedFloors.end(), [this](const pair<int, bool>& a, const pair<int, bool>& b) {
               return 1 / (currFloor - a.first) > 1 / (currFloor - b.first);
           });
      }
   }
   
}

// Checks is the domain name is valid
void Elevator::Moving() {
   while(pressedFloors.size() > 0) {
      bool key = true;
      auto it = find_if( pressedFloors.begin(), pressedFloors.end(),
       [key] (pair<int, bool>& element) { return element.second == key; } );
      
      if(pressedFloors.at(0).first - currFloor > 0) {
         direction = "up";
         if(it != pressedFloors.end()) {
            cout << "Going up..." << endl;
         }
      }
      else if(pressedFloors.at(0).first - currFloor < 0) {
         direction = "down";
         if(it != pressedFloors.end()) {
            cout << "Going down..." << endl;
         }
      }
      int i;
      int startFloor = currFloor;
      for (i = 0; i < abs(pressedFloors.at(0).first - startFloor); ++i)
         {
            if(direction == "up") {
               currFloor = currFloor + 1;
            }
            else if (direction == "down") {
               currFloor = currFloor - 1;
            }
            if(it != pressedFloors.end()) {
               cout << "Floor " << currFloor << endl;
               this_thread::sleep_for(chrono::milliseconds(500));
            }
         }
      if(it != pressedFloors.end()) {
         userFloor = currFloor;
         cout << "Arrived at Floor " << currFloor << endl;
      }
      pressedFloors.erase(pressedFloors.begin());
   }
   
}

void Elevator::PrintElevatorStatus() {
   cout << "\n*******" << endl;
   cout << "Current Floor: " << currFloor << "\t" << "Direction: Heading " << direction << endl;
   cout << "Buttons Pressed: ";
   for (auto floor : pressedFloors) {
      cout << floor.first << ", ";
   }
   cout << endl << "*******\n" << endl;
} 

